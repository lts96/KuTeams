package clientSide;

public class uiThread implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
